from bs4 import BeautifulSoup
import requests, json, time
import steammarket as sm

class CSGOItem:
    url = 'https://steamcommunity.com/market/listings/730/'
    cookie = {'steamLoginSecure': 'STEAM LOGIN COOKIE'}
    name = ''

    def __init__(self, name):
        self.name = name.replace(' ', '%20').replace('|', '%7C')
        self.url = ''.join([self.url, self.name.replace('|', '%7C')])

    def __str__(self):
        print('――――――――――――――――――――――――――――――――――――――――――')
        print('>>> ' + self.name.replace('%20', ' ').replace('%7C', '|'))
        try:
            self.stats()
        except (KeyError, TypeError):
            print('[ Success = False, Invalid Item Name ]')
            print('――――――――――――――――――――――――――――――――――――――――――')
            return ''
        print('――――――――――――――――――――――――――――――――――――――――――')
        print('')

        if self.isCase() or self.isSticker():
            item = sm.get_csgo_item(self.name.replace('%20', ' ').replace('%7C', '|'), currency='USD')
            return 'MARKET: ' + item["lowest_price"] + '\n' + 'MEDIAN PRICE: ' + item["median_price"]

        resp = '\n'.join('{0:8} {1:8}'.format(x, y) for x, y in zip(self.market_prices(), self.market_floats()))
        return resp

    def stats(self):
        item = sm.get_csgo_item(self.name.replace('%20', ' ').replace('%7C', '|'), currency='USD')
        print('[ Success = ' + str(item["success"]) + ', Total Volume = ' + item["volume"] + ' ]')

    def lowest_price(self):
        item = sm.get_csgo_item(self.name.replace('%20', ' ').replace('%7C', '|'), currency='USD')
        return item["lowest_price"]

    def isCase(self):
        if self.name.find('Case') != -1 and self.name.find('Hardened') == -1:
            return True
        return False
    def isSticker(self):
        if self.name.find('Sticker') != -1:
            return True
        return False

    def market_prices(self):
        web_page = requests.get(self.url, cookies=self.cookie)
        soup = BeautifulSoup(web_page.text, features="html.parser")
        price_blocks = soup.findAll('span',{'class':'market_listing_price market_listing_price_with_fee'})
        prices = []

        for i in price_blocks:
            str_data = str(i)
            price = str_data.split('\t')
            prices.append(price[6])
        return prices

    def market_floats(self):
        web_page = requests.get(self.url, cookies=self.cookie)
        soup = BeautifulSoup(web_page.text, features="html.parser")
        script_elements = soup.findAll('script')
        floats = []

        for i in script_elements:
            target = str(i)
            if target.find('var g_rgAssets') != -1:
                sep = target.split(';')
                for x in sep:
                    if str(x).find('var g_rgAssets') != -1:
                        asset = str(x).split(',')
                        id = ''
                        link = ''
                        for item in asset:
                            if str(item).find('\"id\":') != -1:
                                id = str(item)
                                id = id.replace('\"id\":\"', '').replace('\"', '')
                            if str(item).find('\"actions\":') != -1:
                                link = str(item)
                                link = link.replace('"actions":[{"link":"', '').replace('\"', '').replace('\\', '').replace('%assetid%', id)

                                item_data = requests.get('https://api.csgofloat.com/?url=' + link)
                                json_resp = json.loads(item_data.text)
                                item_info = json_resp['iteminfo']
                                floats.append(item_info['floatvalue'])
        return floats

